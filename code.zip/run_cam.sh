./bin/run_cam
